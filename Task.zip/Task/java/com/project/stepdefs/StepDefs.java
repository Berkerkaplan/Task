package com.project.stepdefs;

import com.saf.framework.*;
import db.Methods.DBFunction;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.cucumber.core.api.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.qameta.allure.Allure;
import io.qameta.allure.model.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.Assert;
import org.testng.annotations.Parameters;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

public class StepDefs extends MyTestNGBaseClass {

    CommonLib commonLib = new CommonLib();
    int timeout = 30;



    @After
    public void afterScenario(Scenario scenario) {
        System.out.println("After hook");
        if (scenario.isFailed()) {
            try {
                System.out.println("Test finished with error. Initiate the log out process.");
                // oDriver.close();
                oDriver.findElement(By.xpath(" //span[@class=\"flex sot-user-name\"]")).click();
                Thread.sleep(1000);
                oDriver.findElement(By.xpath("//*[@id=\"headerLogout\"]")).click();
                Thread.sleep(1000);
                oDriver.findElement(By.xpath("//*[contains(text(),'Evet')]")).click();
                Thread.sleep(1000);
                if (oDriver.findElement(By.xpath("//*[contains(text(),'Aktivasyon sürecini sonlandırıyorsunuz.')]")).isDisplayed()) {
                    oDriver.findElement(By.xpath("//*[contains(text(),'Evet')]")).click();
                    oDriver.findElement(By.xpath("//*[@id=\"login\"]"));
                    Thread.sleep(1000);
                    System.out.println("Session ended. I successfully logged out");
                    oDriver.quit();
                } else {
                    oDriver.findElement(By.xpath("//*[@id=\"login\"]"));
                    Thread.sleep(1000);
                    System.out.println("Session ended. I successfully logged out");
                    oDriver.quit();
                }
            } catch (Exception e) {
                e.printStackTrace();
                oDriver.quit();
            }
            System.out.println("action for failed scenario.");
        } else {
            oDriver.quit();
        }
    }


    @Given("Open the {string}")
    public void openUrl(String URL) throws Exception {
        commonLib.navigateToURL(oDriver, URL);
    }




    @When("{string} element is not visible at index {int}")
    public void whenAbsentElementVerify(String element, int index) throws Throwable {
        commonLib.checkElementVisibilityByFalseTest(element, index);
    }


    @When("I click {string} element at index {int}")
    public void ElementClick(String element, int index) throws Throwable {
        clickElement(element, index);
    }


    @Then("^I see (.*) page$")
    public void seePage(String page) {
        commonLib.seePage(page);
    }

    @When("^(?:I )?click element: (\\w+(?: \\w+)*) at index (\\d+)")
    public boolean clickElement(String element, int index) {
        WebElement object = commonLib.findElement(element, index);
        boolean flag = false;
        try {
            if (object != null) {
                object.click();
                System.out.println("Clicked on object-->" + element);
                Allure.addAttachment("Element is clicked.", new ByteArrayInputStream(((TakesScreenshot) oDriver).getScreenshotAs(OutputType.BYTES)));
                // reportResult("PASS", "I clicked the element: " + element, true);
                return true;
            }
        } catch (Exception e) {
            //reportResult("FAIL", "I cannot clicked the element: " + element, true);
            Allure.addAttachment("Element is not clicked.", new ByteArrayInputStream(((TakesScreenshot) oDriver).getScreenshotAs(OutputType.BYTES)));
            Assert.fail("Could not clicked the element:" + element);
            flag = false;
        }
        return flag;
    }



    @Then("^I enter \"([^\"]*)\" text to (.*) at index (\\d+)")
    public boolean enterText(String text, String element, int index) throws InterruptedException {
        WebElement object;
        object = commonLib.waitElement(element, timeout, index);
        boolean flag = false;
        try {
            if (object != null) {

                object.sendKeys(text);
                System.out.println("The text has been entered:" + text);
                Allure.addAttachment("The text has been entered.", new ByteArrayInputStream(((TakesScreenshot) oDriver).getScreenshotAs(OutputType.BYTES)));
                //reportResult("PASS", "I entered the text: " + text, true);

                return true;
            }
        } catch (Exception e) {
            Allure.addAttachment("The text has not been entered.", new ByteArrayInputStream(((TakesScreenshot) oDriver).getScreenshotAs(OutputType.BYTES)));
            Assert.fail("Could not entered the text:" + text);
            flag = false;
        }
        return flag;
    }



    @Then("^I clear text to (.*) at index (\\d+)")
    public boolean clearText(String element, int index) throws InterruptedException {
        WebElement object;
        object = commonLib.waitElement(element, timeout, index);
        boolean flag = false;
        try {
            if (object != null) {
                object.click();
                Thread.sleep(1000);
                object.sendKeys(Keys.CONTROL, "a");
                object.sendKeys(Keys.DELETE);
                Thread.sleep(1000);
                System.out.println("The text has been deleted.");
                Allure.addAttachment("The text has been deleted.", new ByteArrayInputStream(((TakesScreenshot) oDriver).getScreenshotAs(OutputType.BYTES)));
                //  reportResult("PASS", "The text has been deleted.", true);
                return true;
            }
        } catch (Exception e) {
            System.out.println("The text has not been deleted.");
            Allure.addAttachment("The text has not been deleted.", new ByteArrayInputStream(((TakesScreenshot) oDriver).getScreenshotAs(OutputType.BYTES)));
            //reportResult("FAIL", "The text has not been deleted", true);
            Assert.fail("Waiting element is not found!");
            flag = false;
        }
        return flag;
    }



    @And("^I need to just wait")
    public void justWait() throws InterruptedException {
        Thread.sleep(25000);
    }

    @Given("I wait for {int} seconds")
    public void sleep(int sec) throws InterruptedException {
         commonLib.sleep(sec);
    }




    @When("I click element: {string} if it exists at index {int}")
    public void clickIfExists(String element, int index) {
        boolean flag = false;
        try {
            WebElement object = commonLib.findElement(element, index, false);
            if (object != null && object.isDisplayed()) {
                System.out.println(element + " exists.");
                object.click();
                Allure.addAttachment("Element is clicked.", new ByteArrayInputStream(((TakesScreenshot) oDriver).getScreenshotAs(OutputType.BYTES)));
                //reportResult("PASS", "I clicked the element: " + element, true);
                flag = true;
            } else {
                System.out.println(element + " does not exist.");
                Allure.addAttachment("Element does not exist.", new ByteArrayInputStream(((TakesScreenshot) oDriver).getScreenshotAs(OutputType.BYTES)));
                Allure.step("The element does not exist", Status.SKIPPED);
                flag = false;
            }
        } catch (Exception e) {
            Allure.addAttachment("Element does not exist.", new ByteArrayInputStream(((TakesScreenshot) oDriver).getScreenshotAs(OutputType.BYTES)));
            Allure.step("The element does not exist", Status.SKIPPED);
        }
    }


    @When("change tab")
    public void goToNewTab() throws NullPointerException{
        ArrayList<String> tabs2 = new ArrayList<String>(oDriver.getWindowHandles());

        oDriver.switchTo().window(tabs2.get(1));
       // oDriver.navigate().to("https://www.w3schools.com/html/tryit.asp?filename=tryhtml_default");

    }

    @When("clear text")
    public void clearText() throws NullPointerException{

     //   WebElement textField =  commonLib.findElement("text box",1);

      //  commonLib.findElement("text box", 1).click();

       // oDriver.findElement(By.xpath("//div[@id='textarea']")).sendKeys(Keys.chord(Keys.CONTROL, "a"), "berk");

      //  commonLib.findElement("text box",1).sendKeys("<html>TEST</html>" );


       // textField.sendKeys("TEST CASE");

       // textField.clear();

        Actions actions = new Actions (oDriver);
        actions.click(oDriver.findElement(By.xpath("//div[@id='textarea']")))
        .keyDown(Keys.CONTROL)
        .sendKeys("a")
        .keyUp(Keys.CONTROL)
        .sendKeys(Keys.BACK_SPACE)
        .sendKeys("<html>TEST</html>")
        .build()
        .perform();



      // actions.sendKeys(oDriver.findElement(By.xpath("//div[@id='textarea']"))).sendKeys("berk");


    }

}


